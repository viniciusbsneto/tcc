**Notice of Exception and Use Restriction**

Copyright © [2017] Unity Technologies ApS
 
Unity Technologies ApS (“Unity”) grants you a limited, non-exclusive, non-transferable, royalty-free license, without the right to sublicense, to access, view, download, modify, and use the software made available under this license solely for your personal and non-commercial purposes. No distribution, sale, offer for sale, transfer, public display, public performance, transmission, broadcast, or other use not expressly allowed by this license is permitted.
 
THE SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, AND IS PROVIDED WITHOUT WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND/OR NONINFRINGEMENT. IN NO EVENT SHALL UNITY OR ANY OF ITS AFFILIATES BE LIABLE FOR ANY CLAIM, DAMAGES (WHETHER DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL, INCLUDING PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES, LOSS OF USE, DATA, OR PROFITS, AND BUSINESS INTERRUPTION), OR OTHER LIABILITY WHATSOEVER, WHETHER IN AN ACTION OF CONTRACT, TORT, OR OTHERWISE, ARISING FROM OR OUT OF, OR IN CONNECTION WITH, THE SOFTWARE OR THE USE OF OR OTHER DEALINGS IN THE SOFTWARE, EVEN WHERE ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 
This license does not grant you any right or license to use any trademarks, service marks, trade names, products names, or branding of Unity or its affiliates.

Original graphics copyrighted by Michele "Buch" Bucelli (retrieved here: https://opengameart.org/content/a-blocky-dungeon) originally under a CC0 License.
